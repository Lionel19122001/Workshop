def normalize_parameter_name(parameter_name: str) -> str:
    name = str(parameter_name or "").strip()
    if not name:
        raise ValueError("Parameter name is required.")
    return name if name.startswith("/") else f"/{name}"


def first_present(payload: dict, keys) -> object:
    for key in keys:
        if key in payload:
            return payload[key]
    return None
