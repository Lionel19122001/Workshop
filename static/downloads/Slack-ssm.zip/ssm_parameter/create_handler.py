import json
import shlex

from ssm_parameter.createSSM import create_standard_parameter, normalize_parameter_type
from ssm_parameter.payload_utils import first_present, normalize_parameter_name


def _parse_command_text(command_text):
    args = shlex.split(command_text or "")

    while args and args[0].lower() in {"create", "ssm", "standard", "parameter"}:
        args.pop(0)

    named_values = {}
    trailing_text = []
    for token in args:
        if "=" in token:
            key, value = token.split("=", 1)
            key = key.strip().lower()
            if key in {"name", "type", "value", "description", "desc"}:
                named_values[key] = value
                continue
        trailing_text.append(token)

    if {"name", "type", "value"}.issubset(named_values):
        description = named_values.get("description") or named_values.get("desc")
        if trailing_text:
            extra_description = " ".join(trailing_text)
            description = f"{description} {extra_description}" if description else extra_description
        return (
            named_values["name"],
            named_values["type"],
            named_values["value"],
            description,
        )

    if len(args) < 3:
        raise ValueError(
            "Usage: /ssm-create <name> <type> <value> [optional description] or Name=<name> Type=<type> Value=<value>"
        )

    parameter_name = args[0].strip()
    parameter_type = args[1].strip()
    parameter_value = args[2]
    description = " ".join(args[3:]) if len(args) > 3 else None

    return parameter_name, parameter_type, parameter_value, description


def _extract_create_request(payload):
    parameter_name = first_present(payload, ["parameter_name", "name", "Name"])
    parameter_type = first_present(payload, ["parameter_type", "type", "Type"])
    parameter_value = first_present(payload, ["parameter_value", "value", "Value"])
    description = first_present(payload, ["description", "Description"])

    if parameter_name is not None and parameter_type is not None and parameter_value is not None:
        if isinstance(parameter_value, (dict, list)):
            parameter_value = json.dumps(parameter_value, separators=(",", ":"))
        return str(parameter_name), str(parameter_type), str(parameter_value), description

    return _parse_command_text(payload.get("text", ""))


def handle_create(payload, json_response):
    try:
        parameter_name, parameter_type, parameter_value, description = _extract_create_request(payload)
        normalized_type = normalize_parameter_type(parameter_type)
        parameter_version = create_standard_parameter(
            parameter_name=parameter_name,
            parameter_type=normalized_type,
            parameter_value=parameter_value,
            description=description,
            overwrite=True,
        )
    except ValueError:
        return json_response(400, "create failed")
    except Exception:
        return json_response(500, "create failed")

    response_name = normalize_parameter_name(parameter_name)
    success_message = (
        "create success\n"
        f"Name: {response_name}\n"
        f"Type: {normalized_type}\n"
        f"value: {parameter_value}\n"
        f"Version: {parameter_version}"
    )
    return json_response(200, success_message)
