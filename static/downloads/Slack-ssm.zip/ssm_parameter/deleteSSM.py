import boto3
from botocore.exceptions import ClientError


def delete_parameter(
    parameter_name: str,
    ignore_missing: bool = False,
    ssm_client=None,
) -> bool:
    """Delete an SSM parameter and return True when deleted.

    Returns False only when ignore_missing=True and the parameter does not exist.
    """
    name = str(parameter_name or "").strip()
    if not name:
        raise ValueError("Parameter name is required.")
    if not name.startswith("/"):
        name = f"/{name}"

    client = ssm_client or boto3.client("ssm")

    try:
        client.delete_parameter(Name=name)
        return True
    except ClientError as error:
        error_payload = error.response.get("Error", {})
        code = error_payload.get("Code", "Unknown")
        message = error_payload.get("Message", str(error))

        if ignore_missing and code == "ParameterNotFound":
            return False

        raise RuntimeError(f"{code}: {message}") from error
