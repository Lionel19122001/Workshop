import shlex

from ssm_parameter.createSSM import update_parameter_value
from ssm_parameter.payload_utils import first_present, normalize_parameter_name


def _extract_update_request(payload):
    parameter_name = first_present(payload, ["parameter_name", "name", "Name"])
    parameter_value = first_present(payload, ["parameter_value", "value", "Value"])

    if parameter_name is not None and parameter_value is not None:
        return str(parameter_name), str(parameter_value)

    command_text = str(payload.get("text", "")).strip()
    args = shlex.split(command_text)

    named_values = {}
    trailing_text = []
    for token in args:
        if "=" in token:
            key, value = token.split("=", 1)
            key = key.strip().lower()
            if key in {"name", "value"}:
                named_values[key] = value
                continue
        trailing_text.append(token)

    if {"name", "value"}.issubset(named_values):
        parameter_name = named_values["name"].strip()
        parameter_value = named_values["value"]
        if trailing_text:
            parameter_value = f"{parameter_value} {' '.join(trailing_text)}"
        return parameter_name, parameter_value.strip()

    while args and args[0].lower() in {"update", "set", "ssm", "parameter"}:
        args.pop(0)

    if len(args) < 2:
        raise ValueError("Usage: /ssm-update <name> <value>")

    parameter_name = args[0].strip()
    parameter_value = " ".join(args[1:]).strip()

    return parameter_name, parameter_value


def handle_update(payload, json_response):
    parameter_name = None
    try:
        parameter_name, parameter_value = _extract_update_request(payload)
        parameter_version = update_parameter_value(
            parameter_name=parameter_name,
            parameter_value=parameter_value,
        )
    except ValueError as error:
        if str(error) == "not have ssm name":
            missing_name = str(parameter_name or "").strip() or "unknown"
            return json_response(200, f"wrong name, not have ssm name {missing_name}")
        return json_response(400, "update failed")
    except Exception:
        return json_response(500, "update failed")

    response_name = normalize_parameter_name(parameter_name)
    success_message = (
        "update success\n"
        f"Name: {response_name}\n"
        f"value: {parameter_value}\n"
        f"Version: {parameter_version}"
    )
    return json_response(200, success_message)