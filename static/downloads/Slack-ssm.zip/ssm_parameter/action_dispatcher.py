from ssm_parameter.create_handler import handle_create
from ssm_parameter.delete_handler import handle_delete
from ssm_parameter.update_handler import handle_update

ACTION_CREATE = "create"
ACTION_DELETE = "delete"
ACTION_UPDATE = "update"


def extract_action(payload):
    action = str(payload.get("action", payload.get("operation", "")) or "").strip().lower()
    if action in {ACTION_CREATE, ACTION_DELETE, ACTION_UPDATE}:
        return action

    command_name = str(payload.get("command", "") or "").strip().lower()
    if command_name in {"/ssm-delete", "/delete-ssm", "/ssm-remove"}:
        return ACTION_DELETE
    if command_name in {"/ssm-update", "/update-ssm", "/ssm-set"}:
        return ACTION_UPDATE

    text = str(payload.get("text", "") or "").strip().lower()
    if text.startswith("delete ") or text.startswith("remove "):
        return ACTION_DELETE
    if text.startswith("update ") or text.startswith("set "):
        return ACTION_UPDATE

    return ACTION_CREATE


def dispatch_action(payload, json_response):
    action = extract_action(payload)
    handlers = {
        ACTION_CREATE: handle_create,
        ACTION_DELETE: handle_delete,
        ACTION_UPDATE: handle_update,
    }
    handler = handlers.get(action)
    if not handler:
        return json_response(400, "Unsupported action")
    return handler(payload, json_response)
