import shlex

from ssm_parameter.deleteSSM import delete_parameter
from ssm_parameter.payload_utils import first_present, normalize_parameter_name


def _extract_delete_request(payload):
    parameter_name = first_present(payload, ["parameter_name", "name", "Name"])
    if parameter_name is not None:
        return str(parameter_name)

    command_text = str(payload.get("text", "")).strip()
    args = shlex.split(command_text)

    while args and args[0].lower() in {"delete", "remove", "ssm", "parameter"}:
        args.pop(0)

    if args:
        return args[0].strip()

    raise ValueError("Usage: /ssm-delete <name> or Name=<name>")


def handle_delete(payload, json_response):
    try:
        parameter_name = _extract_delete_request(payload)
        deleted = delete_parameter(parameter_name=parameter_name, ignore_missing=True)
    except ValueError:
        return json_response(400, "delete failed")
    except Exception:
        return json_response(500, "delete failed")

    response_name = normalize_parameter_name(parameter_name)
    if deleted:
        return json_response(200, f"delete success\nName: {response_name}")

    return json_response(200, f"not found SSM Parameter \nName: {response_name}")
