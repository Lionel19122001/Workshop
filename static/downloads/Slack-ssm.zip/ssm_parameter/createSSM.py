from typing import Optional

import boto3
from botocore.exceptions import ClientError


_TYPE_MAP = {
    "string": "String",
    "stringlist": "StringList",
    "securestring": "SecureString",
}


def normalize_parameter_type(parameter_type: str) -> str:
    normalized = str(parameter_type or "").strip().lower()
    if normalized not in _TYPE_MAP:
        raise ValueError("type must be one of: String, StringList, SecureString.")
    return _TYPE_MAP[normalized]


def create_standard_parameter(
    parameter_name: str,
    parameter_type: str,
    parameter_value: str,
    description: Optional[str] = None,
    overwrite: bool = True,
    ssm_client=None,
) -> int:
    """Create or update an SSM parameter with Tier=Standard and return its version."""
    name = str(parameter_name or "").strip()
    if not name:
        raise ValueError("Parameter name is required.")
    if not name.startswith("/"):
        name = f"/{name}"

    normalized_type = normalize_parameter_type(parameter_type)

    if parameter_value is None:
        raise ValueError("Parameter value is required.")

    client = ssm_client or boto3.client("ssm")
    request = {
        "Name": name,
        "Value": str(parameter_value),
        "Type": normalized_type,
        "Tier": "Standard",
        "Overwrite": overwrite,
    }

    if description:
        request["Description"] = str(description)

    try:
        response = client.put_parameter(**request)
    except ClientError as error:
        error_payload = error.response.get("Error", {})
        code = error_payload.get("Code", "Unknown")
        message = error_payload.get("Message", str(error))
        if code == "ParameterAlreadyExists":
            raise ValueError("Parameter already exists.") from error
        raise RuntimeError(f"{code}: {message}") from error

    return int(response.get("Version", 1))


def update_parameter_value(
    parameter_name: str,
    parameter_value: str,
    ssm_client=None,
) -> int:
    """Update an existing SSM parameter value and return the new version."""
    name = str(parameter_name or "").strip()
    if not name:
        raise ValueError("Parameter name is required.")
    if not name.startswith("/"):
        name = f"/{name}"

    if parameter_value is None:
        raise ValueError("Parameter value is required.")

    client = ssm_client or boto3.client("ssm")

    try:
        existing = client.get_parameter(Name=name, WithDecryption=False)
    except ClientError as error:
        error_payload = error.response.get("Error", {})
        code = error_payload.get("Code", "Unknown")
        message = error_payload.get("Message", str(error))

        if code == "ParameterNotFound":
            raise ValueError("not have ssm name") from error

        raise RuntimeError(f"{code}: {message}") from error

    existing_type = existing.get("Parameter", {}).get("Type", "String")

    try:
        response = client.put_parameter(
            Name=name,
            Value=str(parameter_value),
            Type=existing_type,
            Overwrite=True,
        )
    except ClientError as error:
        error_payload = error.response.get("Error", {})
        code = error_payload.get("Code", "Unknown")
        message = error_payload.get("Message", str(error))
        raise RuntimeError(f"{code}: {message}") from error

    return int(response.get("Version", 1))
