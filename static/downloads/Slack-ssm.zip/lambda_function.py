import base64
import json
from urllib.parse import parse_qs

from auth.slack_auth import verify_slack_signature
from ssm_parameter.action_dispatcher import dispatch_action


def _json_response(status_code, message, response_type="ephemeral"):
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"response_type": response_type, "text": message}),
    }


def _extract_payload(event):
    if not isinstance(event, dict):
        return {}

    body = event.get("body")
    if body is not None:
        raw_body = body
        if isinstance(raw_body, dict):
            return raw_body

        if event.get("isBase64Encoded"):
            raw_body = base64.b64decode(body).decode("utf-8")

        if not isinstance(raw_body, str):
            return {}

        parsed_payload = parse_qs(raw_body, keep_blank_values=True)
        form_payload = {key: values[0] for key, values in parsed_payload.items()}
        if "text" in form_payload or "command" in form_payload:
            return form_payload

    return {}





def lambda_handler(event, context):
    if not verify_slack_signature(event):
        return _json_response(403, "Invalid Slack signature. Request verification failed.")

    payload = _extract_payload(event)
    if not payload:
        return _json_response(
            400,
            "Payload not found. Send a Slack command request body.",
        )

    return dispatch_action(payload, _json_response)
