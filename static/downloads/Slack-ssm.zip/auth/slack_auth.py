import hashlib
import hmac
import os
import time
from urllib.parse import urlencode

import boto3
from botocore.exceptions import ClientError

# Module-level cache for Slack signing secret (initialized at cold start).
_SLACK_SIGNING_SECRET_CACHE = None
_SECRETS_MANAGER_CLIENT = None


def get_signing_secret():
    """Fetch Slack signing secret from AWS Secrets Manager and cache it in memory."""
    global _SLACK_SIGNING_SECRET_CACHE, _SECRETS_MANAGER_CLIENT

    # Return cached secret if available.
    if _SLACK_SIGNING_SECRET_CACHE is not None:
        return _SLACK_SIGNING_SECRET_CACHE

    # Try to read from Secrets Manager.
    secret_name = os.getenv("SLACK_SIGNING_SECRET_NAME")
    if not secret_name:
        # Fallback: try environment variable (for backward compatibility).
        return os.getenv("SLACK_SIGNING_SECRET")

    try:
        if _SECRETS_MANAGER_CLIENT is None:
            _SECRETS_MANAGER_CLIENT = boto3.client("secretsmanager")

        response = _SECRETS_MANAGER_CLIENT.get_secret_value(SecretId=secret_name)
        secret = response.get("SecretString") or response.get("SecretBinary")

        # Cache the secret in memory for subsequent invocations.
        _SLACK_SIGNING_SECRET_CACHE = secret
        return secret
    except ClientError as error:
        error_code = error.response.get("Error", {}).get("Code", "Unknown")
        print(f"Failed to retrieve secret from Secrets Manager: {error_code}")
        return None


def verify_slack_signature(event):
    """Verify Slack request using HMAC-SHA256 with X-Slack-Signature and X-Slack-Request-Timestamp."""
    signing_secret = get_signing_secret()
    if not signing_secret:
        # If no signing secret configured, allow request (for local testing).
        return True

    headers = event.get("headers", {})
    # Headers may be lowercase in some Lambda contexts.
    slack_signature = headers.get("X-Slack-Signature") or headers.get("x-slack-signature")
    slack_timestamp = headers.get("X-Slack-Request-Timestamp") or headers.get(
        "x-slack-request-timestamp"
    )

    if not slack_signature or not slack_timestamp:
        return False

    try:
        request_time = int(slack_timestamp)
    except (ValueError, TypeError):
        return False

    # Check if request is not too old (5 minutes max, 300 seconds).
    current_time = int(time.time())
    if abs(current_time - request_time) > 300:
        return False

    # Reconstruct the request body exactly as sent.
    body = event.get("body", "")
    if isinstance(body, dict):
        body = urlencode(body)
    elif not isinstance(body, str):
        body = ""

    # Create the signature base string: v0:timestamp:body
    sig_basestring = f"v0:{slack_timestamp}:{body}"

    # Compute the signature using HMAC-SHA256.
    my_signature = "v0=" + hmac.new(
        signing_secret.encode(),
        sig_basestring.encode(),
        hashlib.sha256,
    ).hexdigest()

    # Compare signatures using constant-time comparison to prevent timing attacks.
    return hmac.compare_digest(my_signature, slack_signature)
